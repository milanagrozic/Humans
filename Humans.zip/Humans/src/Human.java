import java.time.LocalDateTime;

public class Human {
	
	int birthYear;
	int birthMonth;
	int birthDay;
	String firstName;
	String lastName;
	Gender gender;
	int age = 0;

	public Human(int birthYear, int birthMonth, int birthDay, String firstName, String lastName, Gender gender) {
		this.birthYear = birthYear;
		this.birthMonth = birthMonth;
		this.birthDay = birthDay;
		this.firstName = firstName;
		this.lastName = lastName;
		this.gender = gender;	
	}

	public int getBirthYear() {
		return birthYear;
	}

	public int getBirthMonth() {
		return birthMonth;
	}
	
	public int getBirthDay() {
		return birthDay;
	}

	public String getFirstName() {
		return firstName;
	}

	public String getLastName() {
		return lastName;
	}
	
	public Gender getGender() {
		return gender;
	}
	
	public int calculateCurrentAgeInYears() {
		  LocalDateTime currentdate = LocalDateTime.now();
	      int currentDay = currentdate.getDayOfMonth();
	      int currentMonth = currentdate.getMonthValue();
	      int currentYear = currentdate.getYear();
		
		if(currentMonth >= birthMonth) {
			if(currentDay >= birthDay) {
				age = currentYear  - birthYear;
			} else {
				age = currentYear  - birthYear -1;
			}		
		} else {
			age = currentYear  - birthYear - 1;
		}
		return age;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public void setLastName(String lastName) {
		// TODO Auto-generated method stub
		this.lastName = lastName;
	}

}
